using CourseDomain.DTOs;
using CourseWeb.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CourseWeb.Pages.Admin
{
    public class IndexModel : PageModel
    {
        private readonly IUserService _userService;

        public IndexModel(IUserService userService)
        {
            _userService = userService;
        }
       
        [BindProperty]
        public List<UserDTO> Users { get; set; }
        public int TotalUsers { get; set; }
        public async Task OnGetAsync()
        {
          
            
            var users = await _userService.GetListUser();
            Users = users;
            TotalUsers = await _userService.GetTotalUsersAsync();

        }
    }
}
